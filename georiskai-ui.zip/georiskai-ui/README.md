# GeoRisk AI - Frontend

Aplicación React que consume la API GeoRisk.

## Instalación

```bash
npm install
npm run dev
```

Corre en:

```
http://localhost:5173
```

---

## Configuración API

En `App.jsx` asegúrate de que la URL coincida con el backend:

```javascript
http://localhost:5000/api/risk/
```

---

## Funcionalidades

- Consulta por país
- Resumen dividido en párrafos
- Eventos importantes listados
- Diseño moderno