import React, { useState } from "react";
import "./App.css";

function App() {
    const [country, setCountry] = useState("");
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);

    const getCountry = async () => {
        if (!country) return;

        setLoading(true);
        setData(null);

        try {
            const res = await fetch(`http://localhost:5000/api/risk/${country}`);
            const json = await res.json();
            setData(json);
        } catch {
            setData({ error: "Error consultando la API" });
        }

        setLoading(false);
    };

    const renderResult = () => {
        if (!data || data.error) return null;

        const text = data.summary || "";

        const splitText = text.split(/Eventos importantes:/i);

        const countryInfo = splitText[0];
        const eventsText = splitText[1] || "";

        const events = eventsText
            .split(/\d+\./)
            .map(e => e.trim())
            .filter(e => e.length > 0);

        return (
            <div className="result">
                <h2>{data.country}</h2>
                <p className="region"> Región: {data.region}</p>

                <div className="country-info">
                    <h3>Resumen del país</h3>
                    {countryInfo
                        .split(/\r?\n/)
                        .filter(p => p.trim() !== "")
                        .map((paragraph, index) => (
                            <p key={index}>{paragraph}</p>
                        ))}
                </div>

                {events.length > 0 && (
                    <div className="events">
                        <h3> Eventos importantes</h3>
                        <ul>
                            {events.map((event, index) => (
                                <li key={index}>{event}</li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className="container">
            <div className="card">
                <h1 className="title">GeoRisk AI</h1>
                <p className="subtitle">Consulta Cultural</p>

                <div className="search-box">
                    <input
                        value={country}
                        onChange={(e) => setCountry(e.target.value)}
                        placeholder="Escribe un país..."
                        className="input"
                    />
                    <button onClick={getCountry} className="button">
                        {loading ? "Cargando..." : "Consultar"}
                    </button>
                </div>

                {renderResult()}

                {data && data.error && (
                    <div className="error">
                        {data.error}
                    </div>
                )}
            </div>
        </div>
    );
}

export default App;